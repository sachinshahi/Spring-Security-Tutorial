package com.sachin.security.springsecurityfacebooklogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsecurityFacebookLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
